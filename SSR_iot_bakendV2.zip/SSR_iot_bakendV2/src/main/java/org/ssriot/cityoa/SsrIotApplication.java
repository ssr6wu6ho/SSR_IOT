package org.ssriot.cityoa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsrIotApplication {

    public static void main(String[] args) {
        SpringApplication.run(SsrIotApplication.class, args);
    }

}
